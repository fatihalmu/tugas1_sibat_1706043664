package tugas1_1706043664.Sibat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SibatApplication {

	public static void main(String[] args) {
		SpringApplication.run(SibatApplication.class, args);
	}

}
