package tugas1_sibat_1706043664.aplikasi_sibat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AplikasiSibatApplication {

	public static void main(String[] args) {
		SpringApplication.run(AplikasiSibatApplication.class, args);
	}

}
