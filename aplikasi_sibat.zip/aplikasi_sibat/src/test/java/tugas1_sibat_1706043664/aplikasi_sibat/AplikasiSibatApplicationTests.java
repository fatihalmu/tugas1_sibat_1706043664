package tugas1_sibat_1706043664.aplikasi_sibat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AplikasiSibatApplicationTests {

	@Test
	void contextLoads() {
	}

}
